package com.example.lostandfound.config

/**
 * Where the app finds its backend (Supabase). Both values are PUBLIC identifiers made to be shipped inside
 * an app: what a signed-in user may read or change is enforced by the database's Row Level Security, not by
 * keeping these secret.
 *
 * NEVER put the "service_role" / "secret" key here. That key bypasses all security rules.
 *
 * While either value is blank the app runs in DEMO mode with an in-memory mock backend.
 */
object BackendConfig {
    /** Supabase dashboard -> Project Settings -> API -> Project URL, e.g. "https://abcdxyz.supabase.co". */
    const val SUPABASE_URL = "https://xnpchubfavaexcqnaxvv.supabase.co"

    /** Supabase dashboard -> Project Settings -> API Keys -> the "anon" / "publishable" key. */
    const val SUPABASE_ANON_KEY = "sb_publishable_NCYciKrDKuSdHbdoxrH3yQ_b-riP3Bt"

    val isConfigured: Boolean
        get() = SUPABASE_URL.startsWith("https://") && SUPABASE_ANON_KEY.isNotBlank()
}
