# Legacy AWS version (not deployed)

The first backend was designed for AWS (Cognito, API Gateway, Lambda, DynamoDB, S3, SQS, EventBridge, CloudFormation).
The project moved to **Supabase** (see `../supabase`) because the AWS account could not be activated for this project.

This code is kept for reference and still passes its own tests. It is **not used by the app**.

```
backend/    CloudFormation template, Lambda code, deploy scripts, 49 tests
extractor/  CLIP image-embedding Lambda (container)
```
Run its tests: `cd backend && pip install -r requirements-dev.txt && python -m unittest discover -s tests -t .`
